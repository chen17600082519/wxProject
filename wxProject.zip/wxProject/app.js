App({
  globalData:{
    g_isPlayingMusic:false, //全局变量，使用getApp().globaData获取
    g_currentMusicPostId:null,//当前正在播放的音乐
    doubanBase:"http://t.yushu.im"
  }
  // onLaunch:function(){
  //   console.log('onLaunch')
  // },
  // onShow:function(){
  //   console.log('onShow')
  // },
  // onHide:function(){
  //   //真机运行里，Home键，小程序后台运行时，此方法调用
  //   console.log('onHide')
  // }
})
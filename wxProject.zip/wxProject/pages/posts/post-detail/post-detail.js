var postsData = require('../../../data/posts-data.js');
var app=getApp();
Page({
  data:{
    isPlayingMusic: false
  },
  onLoad:function(option){
    var postId = option.id;
    this.data.postId = postId;
    var postData = postsData.postList[postId];
    this.setData({
      postData:postData
    });
    var postsCollected = wx.getStorageSync('postsCollected');
    if(postsCollected){
      var postCollected = postsCollected[postId] || false;
      this.setData({
        collected:postCollected
      });
    }else{
      var postsCollected = {};
      postsCollected[postId] = false;
      wx.setStorageSync('postsCollected', postsCollected);
    }
    if (app.globalData.g_isPlayingMusic && app.globalData.g_currentMusicPostId === this.data.postId){
      this.setData({
        isPlayingMusic: true
      });
    }
    this.setMusicMonitor();
  },
  setMusicMonitor(){
    var that = this;
    wx.onBackgroundAudioPlay(function (e) {
      if (app.globalData.g_currentMusicPostId === that.data.postId){
        that.setData({
          isPlayingMusic: true
        });
      }
      app.globalData.g_isPlayingMusic = true;
    });
    wx.onBackgroundAudioPause(function () {
      if (app.globalData.g_currentMusicPostId === that.data.postId) {
        that.setData({
          isPlayingMusic: false
        });
      }
      app.globalData.g_isPlayingMusic = false;
    });
    wx.onBackgroundAudioStop(function () {
      if (app.globalData.g_currentMusicPostId === that.data.postId) {
        that.setData({
          isPlayingMusic: false
        });
      }
      app.globalData.g_isPlayingMusic = false;
      app.globalData.g_currentMusicPostId = null;
    });
  },
  onCollectionTap:function(e){
    var postsCollected = wx.getStorageSync('postsCollected');
    var postCollected = postsCollected[this.data.postId];
    postCollected = !postCollected;
    postsCollected[this.data.postId] = postCollected;
    this.showModal(postsCollected, postCollected);
  },
  showModal(postsCollected, postCollected){
    var that=this;
    wx.showModal({
      content: postCollected ? "确定收藏吗？":"确定要取消收藏吗？",
      showCancel: "true",
      cancelText: "否",
      cancelColor: "#333",
      confirmText: "确定",
      success:function(res){
        if(res.confirm){
          wx.setStorageSync('postsCollected', postsCollected);
          that.setData({
            collected: postCollected
          });
          that.showToast(postCollected);
        }
      }
    });
  },
  showToast(postCollected){
    wx.showToast({
      title: postCollected ? "收藏成功" : "取消收藏",
      duration: 1000,
      icon: "success"
    });
  },
  onShareTap: function (e) {
    var itemList = [
      "分享给微信好友",
      "分享到朋友圈",
      "分享到QQ",
      "分享到微博"
    ];
    wx.showActionSheet({
      itemList:itemList,
      success:function(res){
        //res.cancel 用户是不是点击了取消按钮
        //res.tapIndex 数组元素的序号，从0开始
        wx.showModal({
          title: '用户' + itemList[res.tapIndex],
          content:"现在无法实现分享功能"
        })
      }
    });
  },
  onMusicTap:function(){
    if (app.globalData.g_currentMusicPostId === this.data.postId && app.globalData.g_isPlayingMusic){
        wx.pauseBackgroundAudio();
    }else{
      var that = this;
      var post = postsData.postList[that.data.postId];
      wx.playBackgroundAudio({
        dataUrl: post.music.url,
        title: post.music.title,
        coverImgUrl: post.music.coverImg,
        success: function () {
          that.setData({
            isPlayingMusic: true
          });
          app.globalData.g_isPlayingMusic = true;
          if(app.globalData.g_currentMusicPostId !== that.data.postId){
            app.globalData.g_currentMusicPostId = that.data.postId;
          }
        },
        fail: function (err) {
          alert("播放失败");
          console.log(err);
        }
      });
    }
  }
});
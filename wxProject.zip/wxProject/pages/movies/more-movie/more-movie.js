Page({
  data: {
    movies:[],
    noMore:false
  },
  onLoad: function (options) {
    var that = this;
    var leixing = options.leixing;
    var movieUrl = options.movieUrl;
    this.data.movieUrl = movieUrl;
    wx.setNavigationBarTitle({
      title: leixing
    });
    wx.request({
      url: movieUrl,
      method: 'GET',
      header: {
        "content-type": "application/json"
      },
      success: function (res) {
        that.setData({
          movies:res.data.subjects
        })
      },
      fail: function (err) {
        console.log(err);
      }
    });
  },
  onReachBottom:function(e){
    var that = this;
    if(this.data.noMore){
      return;
    }else{
      var nextUrl = this.data.movieUrl + "?start=" + (this.data.movies.length) + "&count=10";
      wx.showNavigationBarLoading();
      wx.request({
        url: nextUrl,
        method: 'GET',
        header: {
          "content-type": "application/json"
        },
        success: function (res) {
          if (res.data.subjects.length == 0) {
            that.setData({
              noMore: true
            });
            return;
          }else{
            that.setData({
              movies: that.data.movies.concat(res.data.subjects)
            });
          };
          
        },
        fail: function (err) {
          console.log(err);
        },
        complete: function (res) {
          wx.hideNavigationBarLoading();
        }
      });
    }
  },
  onPullDownRefresh: function () {
    var that = this;
    var newUrl = this.data.movieUrl + "?start=0&count=20";
    wx.showNavigationBarLoading();
    wx.request({
      url: newUrl,
      data: {},
      method: 'GET',
      success: function (res) {
        that.setData({
          movies: res.data.subjects,
          noMore:false
        });
      },
      fail: function (err) {
        console.log(err);  
      },
      complete: function (res) {
        wx.stopPullDownRefresh();
        wx.hideNavigationBarLoading();
      }
    })
  },
  onMovieTap: function (e) {
    var movieId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../movie-detail/movie-detail?id=' + movieId
    });
  },
})
var app = getApp();
Page({
  data:{
    inTheatersl:{},
    comingSoon:{},
    top250:{},
    searchMovies:{},
    searchPanelShow:false
  },
  onLoad:function(){
    var inTheatersUrl = app.globalData.doubanBase + "/v2/movie/in_theaters";
    var comingSoonUrl = app.globalData.doubanBase + "/v2/movie/coming_soon";
    var top205Url = app.globalData.doubanBase + "/v2/movie/top250";
    this.getMovieData(inTheatersUrl,"inTheatersl");
    this.getMovieData(comingSoonUrl,"comingSoon");
    this.getMovieData(top205Url,"top205");
  },
  getMovieData:function(url,setkey){
    var that = this;
    wx.request({
      url: url + "?start=0&count=3",
      method: 'GET',
      header: {
        "content-type": "application/json"
      },
      success: function (res) {
        var readyData={};
        readyData[setkey] = {
          movies: res.data.subjects,
          movieUrl:url
        };
        that.setData(readyData);
      },
      fail: function (err) {
        console.log(err);
      }
    });
  },
  getSearchMovie: function (url, setkey) {
    var that = this;
    wx.request({
      url: url,
      method: 'GET',
      header: {
        "content-type": "application/json"
      },
      success: function (res) {
        var readyData = {};
        readyData[setkey] = {
          movies: res.data.subjects
        };
        that.setData(readyData);
      },
      fail: function (err) {
        console.log(err);
      }
    });
  },
  onMoreTap:function(e){
    var leixing = e.currentTarget.dataset.leixing;
    var movieUrl = e.currentTarget.dataset.movieUrl;
    wx.navigateTo({
      url: 'more-movie/more-movie?leixing='+leixing+'&movieUrl='+movieUrl
    });
  },
  onMovieTap:function(e){
    var movieId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: 'movie-detail/movie-detail?id='+movieId
    });
  },
  onBindFocus:function(e){
    this.setData({
      searchPanelShow: true
    });
    var text = e.detail.value;
    if(text!=''){
      var searchUrl = app.globalData.doubanBase + "/v2/movie/search?q=" + text;
      this.getSearchMovie(searchUrl, "searchMovies");
    }
  },
  onBindChange:function(e){
    var text = e.detail.value;
    var searchUrl = app.globalData.doubanBase + "/v2/movie/search?q=" + text;
    this.getSearchMovie(searchUrl,"searchMovies");
  },
  onCancelImgTap:function(){
    this.setData({
      searchPanelShow: false,
      searchMovies:{}
    })
  }
})
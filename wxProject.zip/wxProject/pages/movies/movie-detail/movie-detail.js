var app = getApp();
Page({
  data: {
    movie:{}
  },
  onLoad: function (options) {
    var that = this;
    var movieId = options.id;
    var url =app.globalData.doubanBase + "/v2/movie/subject/" + movieId;
    wx.request({
      url: url,
      method: 'GET',
      header: {
        "content-type": "application/json"
      },
      success: function (res) {
        that.setData({
          movie:res.data
        });
      },
      fail: function (err) {
        console.log(err);
      }
    });
  },
  viewMoviePostImg:function(e){
    var src = e.currentTarget.dataset.src;
    wx.previewImage({
      currrent:src,//当前显示图片的http链接
      urls: [src] //需要预览的图片http链接列表
    });
  }
})